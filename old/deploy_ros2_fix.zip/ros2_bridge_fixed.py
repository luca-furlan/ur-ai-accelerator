#!/usr/bin/env python3
"""
ROS2 bridge for web interface.
Provides publishers for UR robot commands via ROS2 topics.
"""
import os
import sys

# Try to source ROS2 setup if not already done
if 'ROS_DISTRO' not in os.environ:
    ros_setup = '/opt/ros/humble/setup.bash'
    if os.path.exists(ros_setup):
        # Try to get ROS2 Python path
        import subprocess
        try:
            # Source ROS2 and get Python path
            cmd = f'source {ros_setup} && python3 -c "import sys; print(\":\".join(sys.path))"'
            result = subprocess.run(['bash', '-c', cmd], 
                                  capture_output=True, text=True, timeout=3)
            if result.returncode == 0 and result.stdout.strip():
                paths = result.stdout.strip().split(':')
                for p in paths:
                    if p and p not in sys.path and 'ros' in p.lower():
                        sys.path.insert(0, p)
        except Exception as e:
            print(f'Warning: Could not source ROS2 setup: {e}')

try:
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import Float64MultiArray, Empty
    from geometry_msgs.msg import Twist
    ROS2_AVAILABLE = True
except ImportError as e:
    ROS2_AVAILABLE = False
    Node = None
    print(f'⚠️ ROS2 not available: {e}')

import threading


class ROS2Bridge:
    """Singleton ROS2 bridge for web interface."""
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._initialized = True
        self._node = None
        self._publishers = {}
        self._ros_thread = None
        self._ros_initialized = False
        
    def _init_ros(self):
        """Initialize ROS2 in a separate thread."""
        if self._ros_initialized:
            return
        
        if not ROS2_AVAILABLE:
            print('⚠️ ROS2 not available (rclpy not found). Web interface will work but ROS2 commands will fail.')
            return
        
        try:
            if not rclpy.ok():
                rclpy.init()
            
            self._node = Node('web_interface_bridge')
            
            # Create publishers - usa topic reali del driver UR
            # Per movej: usa joint_trajectory_controller
            try:
                from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
                self._publishers['movej'] = self._node.create_publisher(
                    JointTrajectory,
                    '/scaled_joint_trajectory_controller/joint_trajectory',
                    10
                )
                self._trajectory_msg_type = JointTrajectory
                self._trajectory_point_type = JointTrajectoryPoint
            except ImportError:
                self._publishers['movej'] = None
                self._trajectory_msg_type = None
                self._trajectory_point_type = None
            
            # Per speedj: usa forward_velocity_controller (controllo velocità diretto)
            # Questo è il controller principale per controllo fluido in ROS2
            self._publishers['speedj'] = self._node.create_publisher(
                Float64MultiArray,
                '/forward_velocity_controller/commands',
                10
            )
            
            # Twist per controllo cartesiano - il driver UR non ha un topic twist diretto
            # Per ora usiamo solo joint control via forward_velocity_controller
            self._publishers['twist'] = None
            self._publishers['servo_twist'] = None
            
            # Stop: usa lo stesso publisher di speedj (invia velocità zero)
            self._publishers['stop'] = self._publishers['speedj']
            
            self._ros_initialized = True
            print('✅ ROS2 bridge initialized')
            
            # Spin in background
            def spin_ros():
                try:
                    rclpy.spin(self._node)
                except:
                    pass
            
            self._ros_thread = threading.Thread(target=spin_ros, daemon=True)
            self._ros_thread.start()
            
        except Exception as e:
            print(f'⚠️ Failed to initialize ROS2: {e}')
            import traceback
            traceback.print_exc()
            self._ros_initialized = False
    
    def ensure_ros(self):
        """Ensure ROS2 is initialized."""
        if not self._ros_initialized:
            self._init_ros()
        return self._ros_initialized
    
    def publish_movej(self, joints):
        """Publish movej command usando JointTrajectory."""
        if not self.ensure_ros():
            return False
        
        try:
            if self._publishers.get('movej') and self._trajectory_msg_type:
                msg = self._trajectory_msg_type()
                point = self._trajectory_point_type()
                point.positions = [float(j) for j in joints]
                point.time_from_start.sec = 1
                point.time_from_start.nanosec = 0
                msg.points = [point]
                # Nomi joint standard UR
                msg.joint_names = ['shoulder_pan_joint', 'shoulder_lift_joint', 
                                  'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
                self._publishers['movej'].publish(msg)
                return True
            else:
                # Fallback: usa speedj con velocità zero dopo movimento
                return False
        except Exception as e:
            print(f'Error publishing movej: {e}')
            import traceback
            traceback.print_exc()
            return False
    
    def publish_speedj(self, speeds):
        """Publish speedj command."""
        if not self.ensure_ros():
            return False
        
        try:
            msg = Float64MultiArray()
            msg.data = [float(s) for s in speeds]
            self._publishers['speedj'].publish(msg)
            return True
        except Exception as e:
            print(f'Error publishing speedj: {e}')
            return False
    
    def publish_twist(self, linear, angular, use_servo_node=True):
        """Publish Twist command. 
        Nota: Il driver UR standard non supporta controllo cartesiano diretto via ROS2.
        Per controllo fluido, usa publish_speedj con velocità joint calcolate.
        """
        if not self.ensure_ros():
            return False
        
        # Il driver UR non ha un topic twist diretto
        # Per controllo cartesiano fluido, bisognerebbe:
        # 1. Abilitare il servo node (richiede configurazione aggiuntiva)
        # 2. Oppure convertire twist in velocità joint usando cinematica inversa
        # Per ora restituiamo False e lasciamo che il web interface usi speedj
        print('⚠️ Controllo cartesiano diretto non disponibile - usa joint control')
        return False
    
    def publish_stop(self):
        """Publish stop command - invia velocità zero a forward_velocity_controller."""
        if not self.ensure_ros():
            return False
        
        try:
            # Invia velocità zero a tutti i joint via forward_velocity_controller
            msg = Float64MultiArray()
            msg.data = [0.0] * 6
            if self._publishers.get('speedj'):
                self._publishers['speedj'].publish(msg)
                return True
            return False
        except Exception as e:
            print(f'Error publishing stop: {e}')
            return False
    
    def shutdown(self):
        """Shutdown ROS2."""
        if self._node and ROS2_AVAILABLE and rclpy.ok():
            try:
                self._node.destroy_node()
                rclpy.shutdown()
            except:
                pass



