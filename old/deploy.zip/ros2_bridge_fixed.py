#!/usr/bin/env python3
"""
ROS2 bridge for web interface.
Provides publishers for UR robot commands via ROS2 topics.
"""
import os
import sys

# Try to source ROS2 setup if not already done
if 'ROS_DISTRO' not in os.environ:
    ros_setup = '/opt/ros/humble/setup.bash'
    if os.path.exists(ros_setup):
        # Try to get ROS2 Python path
        import subprocess
        try:
            # Source ROS2 and get Python path
            cmd = f'source {ros_setup} && python3 -c "import sys; print(\":\".join(sys.path))"'
            result = subprocess.run(['bash', '-c', cmd], 
                                  capture_output=True, text=True, timeout=3)
            if result.returncode == 0 and result.stdout.strip():
                paths = result.stdout.strip().split(':')
                for p in paths:
                    if p and p not in sys.path and 'ros' in p.lower():
                        sys.path.insert(0, p)
        except Exception as e:
            print(f'Warning: Could not source ROS2 setup: {e}')

try:
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import Float64MultiArray, Empty
    from geometry_msgs.msg import Twist
    ROS2_AVAILABLE = True
except ImportError as e:
    ROS2_AVAILABLE = False
    Node = None
    print(f'⚠️ ROS2 not available: {e}')

import threading


class ROS2Bridge:
    """Singleton ROS2 bridge for web interface."""
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._initialized = True
        self._node = None
        self._publishers = {}
        self._ros_thread = None
        self._ros_initialized = False
        
    def _init_ros(self):
        """Initialize ROS2 in a separate thread."""
        if self._ros_initialized:
            return
        
        if not ROS2_AVAILABLE:
            print('⚠️ ROS2 not available (rclpy not found). Web interface will work but ROS2 commands will fail.')
            return
        
        try:
            if not rclpy.ok():
                rclpy.init()
            
            self._node = Node('web_interface_bridge')
            
            # Create publishers
            self._publishers['movej'] = self._node.create_publisher(
                Float64MultiArray,
                '/ur_controller/movej',
                10
            )
            
            self._publishers['speedj'] = self._node.create_publisher(
                Float64MultiArray,
                '/ur_controller/speedj',
                10
            )
            
            # Twist per controllo generale
            self._publishers['twist'] = self._node.create_publisher(
                Twist,
                '/ur_controller/twist',
                10
            )
            
            # TwistStamped per servo node (controllo fluido)
            try:
                from geometry_msgs.msg import TwistStamped
                self._publishers['servo_twist'] = self._node.create_publisher(
                    TwistStamped,
                    '/servo_node/delta_twist_cmds',
                    10
                )
            except ImportError:
                self._publishers['servo_twist'] = None
            
            self._publishers['stop'] = self._node.create_publisher(
                Empty,
                '/ur_controller/stop',
                10
            )
            
            self._ros_initialized = True
            print('✅ ROS2 bridge initialized')
            
            # Spin in background
            def spin_ros():
                try:
                    rclpy.spin(self._node)
                except:
                    pass
            
            self._ros_thread = threading.Thread(target=spin_ros, daemon=True)
            self._ros_thread.start()
            
        except Exception as e:
            print(f'⚠️ Failed to initialize ROS2: {e}')
            import traceback
            traceback.print_exc()
            self._ros_initialized = False
    
    def ensure_ros(self):
        """Ensure ROS2 is initialized."""
        if not self._ros_initialized:
            self._init_ros()
        return self._ros_initialized
    
    def publish_movej(self, joints):
        """Publish movej command."""
        if not self.ensure_ros():
            return False
        
        try:
            msg = Float64MultiArray()
            msg.data = [float(j) for j in joints]
            self._publishers['movej'].publish(msg)
            return True
        except Exception as e:
            print(f'Error publishing movej: {e}')
            return False
    
    def publish_speedj(self, speeds):
        """Publish speedj command."""
        if not self.ensure_ros():
            return False
        
        try:
            msg = Float64MultiArray()
            msg.data = [float(s) for s in speeds]
            self._publishers['speedj'].publish(msg)
            return True
        except Exception as e:
            print(f'Error publishing speedj: {e}')
            return False
    
    def publish_twist(self, linear, angular, use_servo_node=True):
        """Publish Twist command. Se use_servo_node=True, usa /servo_node/delta_twist_cmds per controllo fluido."""
        if not self.ensure_ros():
            return False
        
        try:
            # Prova servo node per controllo fluido
            if use_servo_node and self._publishers.get('servo_twist'):
                from geometry_msgs.msg import TwistStamped
                from builtin_interfaces.msg import Time
                import time
                
                msg = TwistStamped()
                msg.header.stamp.sec = int(time.time())
                msg.header.stamp.nanosec = int((time.time() % 1) * 1e9)
                msg.header.frame_id = 'base'
                msg.twist.linear.x = float(linear[0])
                msg.twist.linear.y = float(linear[1])
                msg.twist.linear.z = float(linear[2])
                msg.twist.angular.x = float(angular[0])
                msg.twist.angular.y = float(angular[1])
                msg.twist.angular.z = float(angular[2])
                self._publishers['servo_twist'].publish(msg)
                return True
            
            # Fallback a twist normale
            msg = Twist()
            msg.linear.x = float(linear[0])
            msg.linear.y = float(linear[1])
            msg.linear.z = float(linear[2])
            msg.angular.x = float(angular[0])
            msg.angular.y = float(angular[1])
            msg.angular.z = float(angular[2])
            self._publishers['twist'].publish(msg)
            return True
        except Exception as e:
            print(f'Error publishing twist: {e}')
            import traceback
            traceback.print_exc()
            return False
    
    def publish_stop(self):
        """Publish stop command."""
        if not self.ensure_ros():
            return False
        
        try:
            msg = Empty()
            self._publishers['stop'].publish(msg)
            return True
        except Exception as e:
            print(f'Error publishing stop: {e}')
            return False
    
    def shutdown(self):
        """Shutdown ROS2."""
        if self._node and ROS2_AVAILABLE and rclpy.ok():
            try:
                self._node.destroy_node()
                rclpy.shutdown()
            except:
                pass



