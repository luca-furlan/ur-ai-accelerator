"""
Remote UR controller utilities.

This module provides a minimal socket-based interface that can be executed on
the AI Accelerator to drive a Universal Robots arm through URScript commands.

The controller opens a TCP connection (default port 30002) to the robot and
sends small URScript snippets to trigger motion primitives.
"""

from __future__ import annotations

import logging
import socket
import time
from dataclasses import dataclass
from typing import Iterable, Sequence

DEFAULT_PORT = 30002
DASHBOARD_PORT = 29999
DEFAULT_TIMEOUT = 5.0

LOG = logging.getLogger(__name__)


@dataclass
class MoveParameters:
    """Parameters for a UR move command."""

    acceleration: float = 1.2
    velocity: float = 0.25
    blend_radius: float = 0.0
    async_move: bool = False


class RemoteURController:
    """
    Minimal socket client that sends URScript commands to a robot.

    Usage:
        controller = RemoteURController("192.168.10.194")
        controller.connect()
        controller.movej([0, -1.57, 1.57, 0, 1.57, 0])
    """

    def __init__(
        self,
        robot_ip: str,
        port: int = DEFAULT_PORT,
        socket_timeout: float = DEFAULT_TIMEOUT,
    ):
        self.robot_ip = robot_ip
        self.port = port
        self.socket_timeout = socket_timeout
        self._sock: socket.socket | None = None

    # --------------------------------------------------------------------- #
    # Connection management
    # --------------------------------------------------------------------- #
    def connect(self) -> None:
        """Establish the TCP connection to the robot."""
        if self._sock:
            return

        LOG.debug("Connecting to UR robot %s:%s", self.robot_ip, self.port)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(self.socket_timeout)
        sock.connect((self.robot_ip, self.port))
        self._sock = sock
        LOG.info("Connected to UR robot at %s:%s", self.robot_ip, self.port)

    def close(self) -> None:
        """Close the current socket connection."""
        if self._sock:
            LOG.debug("Closing UR robot connection")
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()
            self._sock = None

    # --------------------------------------------------------------------- #
    # Motion primitives
    # --------------------------------------------------------------------- #
    def movej(
        self,
        joints: Sequence[float],
        params: MoveParameters | None = None,
    ) -> None:
        """
        Joint movement using URScript movej command.

        Args:
            joints: target joint positions (radians) length 6.
            params: optional motion parameters.
        """
        if len(joints) != 6:
            raise ValueError("movej expects 6 joint targets")

        params = params or MoveParameters()
        script = (
            "def remote_move():\n"
            f"  movej({self._format_list(joints)}, a={params.acceleration}, "
            f"v={params.velocity}, r={params.blend_radius})\n"
            "end\n"
            "remote_move()\n"
        )
        self._send_script(script, wait=not params.async_move)

    def speedj(
        self,
        joint_speeds: Sequence[float],
        duration: float = 1.0,
        acceleration: float = 1.0,
    ) -> None:
        """
        Joint speed command.

        Args:
            joint_speeds: speed for each joint (rad/s) length 6.
            duration: command duration in seconds.
            acceleration: joint acceleration limit.
        """
        if len(joint_speeds) != 6:
            raise ValueError("speedj expects 6 joint speeds")

        script = (
            "def remote_speed():\n"
            f"  speedj({self._format_list(joint_speeds)}, {acceleration}, {duration})\n"
            "end\n"
            "remote_speed()\n"
        )
        self._send_script(script, wait=True)

    def speedl(
        self,
        cart_speeds: list[float],
        acceleration: float = 0.5,
        duration: float = 0.2,
    ) -> None:
        """Send a speedl command for cartesian velocity control.
        
        Args:
            cart_speeds: [vx, vy, vz, wx, wy, wz] in m/s and rad/s
            acceleration: acceleration in m/s²
            duration: time buffer for command in seconds
        """
        if len(cart_speeds) != 6:
            raise ValueError("speedl expects 6 cartesian speeds [vx,vy,vz,wx,wy,wz]")

        # Use servoc for smoother control at high frequency
        script = (
            "def remote_speedl():\n"
            f"  speedl({self._format_list(cart_speeds)}, {acceleration}, {duration})\n"
            "end\n"
            "remote_speedl()\n"
        )
        self._send_script(script, wait=False)

    def movel_relative(
        self,
        delta_pose: list[float],
        acceleration: float = 0.15,
        velocity: float = 0.02,
        blend: float = 0.02,
    ) -> None:
        """Move tool by relative cartesian offset with smooth blending.
        
        Args:
            delta_pose: [dx, dy, dz, drx, dry, drz] relative to current TCP
            acceleration: acceleration in m/s² (low for smoothness)
            velocity: velocity in m/s (slow for precision)
            blend: blend radius for smooth path (m, larger = smoother)
        """
        if len(delta_pose) != 6:
            raise ValueError("movel_relative expects 6 values [dx,dy,dz,drx,dry,drz]")

        # Use servoj for smoother continuous motion
        script = (
            "def remote_movel_rel():\n"
            "  current = get_actual_tcp_pose()\n"
            f"  target = pose_add(current, p{self._format_list(delta_pose)})\n"
            f"  movel(target, a={acceleration}, v={velocity}, r={blend})\n"
            "end\n"
            "remote_movel_rel()\n"
        )
        self._send_script(script, wait=False)
    
    def get_tcp_pose(self) -> list[float]:
        """Read current TCP pose via URScript feedback.
        
        Returns:
            [x, y, z, rx, ry, rz] pose of tool center point
        """
        script = (
            "def get_pose():\n"
            "  pose = get_actual_tcp_pose()\n"
            "  textmsg(pose)\n"
            "end\n"
            "get_pose()\n"
        )
        # Note: this sends the pose to the log, not back via socket
        # For real feedback use RTDE or Dashboard
        self._send_script(script, wait=False)
        return [0.0] * 6  # Placeholder until RTDE available

    def servoj(
        self,
        target_joints: Sequence[float],
        t: float = 0.008,
        lookahead_time: float = 0.1,
        gain: float = 300.0,
    ) -> None:
        """
        Servo to joint position - per controllo fluido real-time.
        
        Args:
            target_joints: target joint positions (radians) length 6.
            t: time where the command is controlling the robot (seconds, tipicamente 0.008 per 125Hz)
            lookahead_time: time [0.03,0.2] smoothens the trajectory with this lookahead time
            gain: proportional gain for following target position [100,2000]
        """
        if len(target_joints) != 6:
            raise ValueError("servoj expects 6 joint targets")
        
        # Calcola posizione target basata su velocità corrente
        # Per servoj serve la posizione target, non la velocità
        # Quindi calcoliamo: target = current + velocity * t
        script = (
            "def remote_servoj():\n"
            "  current = get_actual_joint_positions()\n"
            f"  target = {self._format_list(target_joints)}\n"
            f"  servoj(target, t={t}, lookahead_time={lookahead_time}, gain={gain})\n"
            "end\n"
            "remote_servoj()\n"
        )
        self._send_script(script, wait=False)
    
    def servoj_velocity(
        self,
        joint_velocities: Sequence[float],
        t: float = 0.008,
        lookahead_time: float = 0.1,
        gain: float = 300.0,
    ) -> None:
        """
        Servo usando velocità - calcola target = current + velocity * t.
        Per controllo fluido real-time.
        """
        if len(joint_velocities) != 6:
            raise ValueError("servoj_velocity expects 6 joint velocities")
        
        script = (
            "def remote_servoj_vel():\n"
            f"  t = {t}\n"
            "  current = get_actual_joint_positions()\n"
            f"  velocities = {self._format_list(joint_velocities)}\n"
            "  target = [current[0] + velocities[0]*t, current[1] + velocities[1]*t, "
            "current[2] + velocities[2]*t, current[3] + velocities[3]*t, "
            "current[4] + velocities[4]*t, current[5] + velocities[5]*t]\n"
            f"  servoj(target, t={t}, lookahead_time={lookahead_time}, gain={gain})\n"
            "end\n"
            "remote_servoj_vel()\n"
        )
        self._send_script(script, wait=False)

    def stop(self) -> None:
        """Send a stopl command to halt motion smoothly."""
        script = "def remote_stop():\n  stopl(1.5)\nend\nremote_stop()\n"
        self._send_script(script, wait=False)

    # --------------------------------------------------------------------- #
    # Helpers
    # --------------------------------------------------------------------- #
    def _send_script(self, script: str, wait: bool) -> None:
        """Send raw URScript ensuring connection is open."""
        for attempt in range(2):
            try:
                if not self._sock:
                    self.connect()
                assert self._sock is not None
                LOG.debug("Sending URScript (attempt %d):\n%s", attempt + 1, script)
                self._sock.sendall(script.encode("utf-8"))

                if wait:
                    time.sleep(0.1)
                return
            except (socket.timeout, OSError) as exc:
                LOG.warning("URScript send failed (%s), reconnecting...", exc)
                self.close()
                if attempt == 1:
                    raise
                time.sleep(0.05)
        raise RuntimeError("Failed to send URScript after retries")

    @staticmethod
    def _format_list(values: Iterable[float]) -> str:
        return "[" + ", ".join(f"{v:.5f}" for v in values) + "]"


class DashboardClient:
    """Simple client for UR Dashboard server (port 29999)."""
    
    def __init__(self, robot_ip: str, port: int = DASHBOARD_PORT):
        self.robot_ip = robot_ip
        self.port = port
        self._sock: socket.socket | None = None
    
    def connect(self) -> None:
        """Connect to Dashboard server."""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(DEFAULT_TIMEOUT)
        self._sock.connect((self.robot_ip, self.port))
        # Read welcome message
        self._sock.recv(1024)
    
    def send_command(self, command: str) -> str:
        """Send command and return response."""
        if not self._sock:
            self.connect()
        assert self._sock is not None
        self._sock.sendall((command + "\n").encode("utf-8"))
        response = self._sock.recv(1024).decode("utf-8").strip()
        return response
    
    def close(self) -> None:
        """Close connection."""
        if self._sock:
            self._sock.close()
            self._sock = None


__all__ = ["RemoteURController", "MoveParameters", "DashboardClient"]

